import React from "react";
import ReactDOM from "react-dom";
import Txt2 from "./Txt2";

function App() {
  const txt1 = <p> Texto 1</p>; //elemento
  return (
    <div>
      {txt1}
      <Txt2 />
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
