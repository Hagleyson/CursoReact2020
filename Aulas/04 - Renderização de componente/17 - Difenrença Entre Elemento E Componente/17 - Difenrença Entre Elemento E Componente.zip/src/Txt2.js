import React from "react";
//componente
function Txt2() {
  return <p> Texto 2 </p>;
}

export default Txt2;
