import React, { useCallback, useEffect, useReducer, useState } from "react";
import ReactDOM from "react-dom";
import counterReducer from "./state/counter/reducer";
import * as counterActions from "./state/counter/actions";
function App() {
  const [state, counterDispacth] = useReducer(
    counterReducer,
    0,
    (defaultValue) => {
      const valueSave = JSON.parse(localStorage.getItem("count"));
      return valueSave !== null ? valueSave : defaultValue;
    }
  );
  const [number, setNumber] = useState(0);
  const handleNumber = useCallback(
    (e) => {
      setNumber(e.target.value);
    },
    [setNumber]
  );
  const handleIncrementar = useCallback(() => {
    counterDispacth(counterActions.increment(number));
  }, [number]);
  const handleDecrementar = useCallback(() => {
    counterDispacth(counterActions.decrement(number));
  }, [number]);
  const handleZerar = useCallback(() => {
    counterDispacth(counterActions.zerar(number));
    localStorage.removeItem("count");
    location.reload();
  }, [number]);
  useEffect(() => {
    localStorage.setItem("count", JSON.stringify(state));
  }, [state]);
  return (
    <>
      <h1>{state}</h1>
      <input type="number" onChange={handleNumber} />
      <button onClick={handleIncrementar}>Incrementar</button>
      <button onClick={handleDecrementar}>Decrementar</button>
      <button onClick={handleZerar}>Limpar</button>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
