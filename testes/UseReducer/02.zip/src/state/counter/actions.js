import * as counterTypes from "./types";

export function decrement(value) {
  return { type: counterTypes.DECREMENT, payload: { value: +value } };
}
export function increment(value) {
  return { type: counterTypes.INCREMENT, payload: { value: +value } };
}
export function zerar(value) {
  return { type: counterTypes.ZERAR, payload: { value: (value = 0) } };
}
