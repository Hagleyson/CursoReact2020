export const DECREMENT = "DECREMENT";
export const INCREMENT = "INCREMENT";
export const ZERAR = "ZERAR";
