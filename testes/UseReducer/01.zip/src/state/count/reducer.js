import * as counterType from "./type";
function contadorReducer(state, action) {
  switch (action.type) {
    case counterType.INCREMENT:
      return state + action.payload.value;
    case counterType.DECREMENT:
      return state + action.payload.value;
    case counterType.ZERAR:
      return (state = action.payload.value);
    default:
      throw new Error();
  }
}
export default contadorReducer;
