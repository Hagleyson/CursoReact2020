import * as counterTypes from "./type";

export function incrementar(value) {
  return { type: counterTypes.INCREMENT, payload: { value: +value } };
}
export function decrementar(value) {
  return { type: counterTypes.DECREMENT, payload: { value: -value } };
}
export function zerar(value) {
  return { type: counterTypes.ZERAR, payload: { value: (value = 0) } };
}
