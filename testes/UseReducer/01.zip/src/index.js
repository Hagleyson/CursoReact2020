import React, { useCallback, useEffect, useReducer, useState } from "react";
import ReactDOM from "react-dom";
import counterReducer from "./state/count/reducer";
import * as conterActions from "./state/count/actions";
function App() {
  const [state, counterDispact] = useReducer(
    counterReducer,
    0,
    (defaultState) => {
      const persistedState = JSON.parse(window.localStorage.getItem("count"));
      return persistedState !== null ? persistedState : defaultState;
    }
  );
  const [valor, setValor] = useState(0);
  const handleIncrement = useCallback(() => {
    counterDispact(conterActions.incrementar(valor));
  }, [valor, counterDispact]);
  const handleDecrement = useCallback(() => {
    counterDispact(conterActions.decrementar(valor));
  }, [valor, counterDispact]);
  const handleZerar = useCallback(() => {
    counterDispact(conterActions.zerar(valor));
  }, [valor, counterDispact]);
  const handleChange = useCallback(
    (e) => {
      setValor(e.target.value);
    },
    [setValor]
  );
  useEffect(() => {
    localStorage.setItem("count", JSON.stringify(state));
  }, [state]);
  const handleLimpar = useCallback(() => {
    localStorage.removeItem("count");
    location.reload();
  });
  return (
    <>
      <h1>{state}</h1>
      <input type="number" onChange={handleChange} />
      <button onClick={handleIncrement}>Incrementar</button>
      <button onClick={handleDecrement}>Decrementar</button>
      <button onClick={handleZerar}>zerar</button>
      <button onClick={handleLimpar}>Limpar</button>
    </>
  );
}
ReactDOM.render(<App />, document.getElementById("root"));
