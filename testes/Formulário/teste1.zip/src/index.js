import React from "react";
import ReactDOM from "react-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import MaskedInput from "react-text-mask";

function App() {
  const formik = useFormik({
    initialValues: {
      name: "",
      phone: "",
      email: "",
      data: "",
      password: ""
    },
    validationSchema: yup.object({
      name: yup.string().required("Campo Obrigatório"),
      phone: yup
        .string()
        .required("Campo Obrigatório")
        .min(14, "telefone Inválido"),
      email: yup
        .string()
        .required("Campo Obrigatório")
        .email("E-mail inválido"),
      data: yup.string().required("Campo Obrigatório").min(10),
      password: yup
        .string()
        .required("Campo Obrigatório")
        .matches(/[?=(0-9)]/, "deve conter um número")
        .matches(/[?=(a-z)]/, "deve conter letra minúscula ")
        .matches(/[?=(A-Z)]/, "deve conter letra maiúscula")
        .min(8, "Deve conter no minimo 8 caracteres")
    }),
    onSubmit(dados) {
      if (formik.isValid) {
        const data = {
          name: dados.name.toLowerCase(),
          phone: dados.phone.replace("(", "").replace(")", "").replace("-", ""),
          email: dados.email.toLocaleLowerCase(),
          data: dados.data.toLowerCase().replace("/", ""),
          password: dados.password
        };
        console.log(data);
        formik.resetForm();
      }
    }
  });
  return (
    <form onSubmit={formik.handleSubmit}>
      <div>
        <input
          type="text"
          placeholder="Nome"
          {...formik.getFieldProps("name")}
        />
        {formik.touched.name && formik.errors.name ? (
          <span>{formik.errors.name}</span>
        ) : null}
      </div>
      <div>
        <MaskedInput
          mask={[
            "(",
            /[?(0-9)]/,
            /[?(0-9)]/,
            ")",
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/,
            "-",
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/
          ]}
          type="text"
          placeholder="Telefone"
          {...formik.getFieldProps("phone")}
        />
        {formik.touched.phone && formik.errors.phone ? (
          <span>{formik.errors.phone}</span>
        ) : null}
      </div>
      <div>
        <input
          type="text"
          placeholder="E-mail"
          {...formik.getFieldProps("email")}
        />
        {formik.touched.email && formik.errors.email ? (
          <span>{formik.errors.email}</span>
        ) : null}
      </div>
      <div>
        <MaskedInput
          mask={[
            /[?(0-9)]/,
            /[?(0-9)]/,
            "/",
            /[?(0-9)]/,
            /[?(0-9)]/,
            "/",
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/,
            /[?(0-9)]/
          ]}
          type="text"
          placeholder="Data"
          {...formik.getFieldProps("data")}
        />
        {formik.touched.data && formik.errors.data ? (
          <span>{formik.errors.data}</span>
        ) : null}
      </div>
      <div>
        <input
          type="text"
          placeholder="Senha"
          {...formik.getFieldProps("password")}
        />
        {formik.touched.password && formik.errors.password ? (
          <span>{formik.errors.password}</span>
        ) : null}
      </div>
      <div>
        <input type="submit" value="enviar" />
      </div>
    </form>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
