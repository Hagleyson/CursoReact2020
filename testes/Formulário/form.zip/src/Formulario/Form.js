import React from "react";
import { useFormik } from "formik";
import "./form.css";
import * as yup from "yup";
import MaskedInput from "react-text-mask";
function receberDados(valor) {
  console.log(valor);
}
function Form() {
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phone: "",
      password: ""
    },
    validationSchema: yup.object({
      name: yup.string().required("Preenchimento Obrigatório"),
      email: yup
        .string()
        .required("Preenchimento Obrigatório!")
        .email("Email invalido"),
      phone: yup
        .string()
        .required("Preenchimento Obrigatório!")
        .min(14, "Telefone Invalido"),
      password: yup
        .string()
        .required("Preenchimento Obrigatório!")
        .matches(/[?=(a-zA-Z)]/, "A senha deve conter uma letra")
        .matches(/[?=(0-9)]/, "A senha deve conter um número")
        .min(8, "A senha deve conter pelo menos 8 caracteres")
    }),
    onSubmit(values) {
      if (formik.isValid) {
        const data = {
          name: values.name.toLocaleLowerCase(),
          email: values.email.toLocaleLowerCase(),
          phone: values.phone
            .replace("(", "")
            .replace("(", "")
            .replace("-", ""),
          password: values.password
        };
        receberDados(data);
        formik.resetForm();
      }
    }
  });

  return (
    <>
      <form onSubmit={formik.handleSubmit} className="form">
        <div>
          <input
            id="name"
            type="text"
            placeholder="Digite seu nome"
            {...formik.getFieldProps("name")}
            autoComplete="off"
          />
          {formik.touched.name && formik.errors.name ? (
            <span>{formik.errors.name}</span>
          ) : null}
        </div>
        <div>
          <input
            type="text"
            placeholder="Digite seu E-mail"
            {...formik.getFieldProps("email")}
            autoComplete="off"
          />
          {formik.touched.email && formik.errors.email ? (
            <span>{formik.errors.email}</span>
          ) : null}
        </div>
        <div>
          <MaskedInput
            mask={[
              "(",
              /[0-9]/,
              /[0-9]/,
              ")",
              /[0-9]/,
              /[0-9]/,
              /[0-9]/,
              /[0-9]/,
              /[0-9]/,
              "-",
              /[0-9]/,
              /[0-9]/,
              /[0-9]/,
              /[0-9]/
            ]}
            type="text"
            placeholder="Digite seu Telefone"
            {...formik.getFieldProps("phone")}
            autoComplete="off"
          />
          {formik.touched.phone && formik.errors.phone ? (
            <span>{formik.errors.phone}</span>
          ) : null}
        </div>
        <div>
          <input
            type="password"
            placeholder="Digite sua senha"
            {...formik.getFieldProps("password")}
            autoComplete="off"
          />
          {formik.touched.password && formik.errors.password ? (
            <span>{formik.errors.password}</span>
          ) : null}
        </div>
        <input type="submit" />
      </form>
    </>
  );
}
export default Form;
