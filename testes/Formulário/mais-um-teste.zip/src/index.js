import React from "react";
import ReactDOM from "react-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import MaskedInput from "react-text-mask";

function App() {
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: ""
    },
    validationSchema: yup.object({
      name: yup.string().required("Campo Obrigatório"),
      email: yup
        .string()
        .required("Campo Obrigatório")
        .email("Email Inválido!"),
      phone: yup
        .string()
        .required("Campo Obrigatório")
        .min(14, "telefone Inválido"),
      password: yup
        .string()
        .required("Campo Obrigatório")
        .matches(/[0-9]/, "A senha deve conter número")
        .matches(/[a-z]/, "A senha deve conter letra minúscula")
        .matches(/[A-Z]/, "A senha deve conter letra maiúscula")
        .min(8, "De conter pelo menos 8 caracteres "),

      confirmPassword: yup
        .string()
        .required("Campo Obrigatório")
        .oneOf([yup.ref("password"), null], "As Senhas não correspondem ")
    }),
    onSubmit(values) {
      if (formik.isValid) {
        const data = {
          name: values.name.toLocaleLowerCase(),
          email: values.email.toLocaleLowerCase(),
          phone: values.phone
            .replace("(", "")
            .replace(")", "")
            .replace("-", ""),
          password: values.password
        };
        console.log(data);
      }
    }
  });
  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <div>
          <input
            autoComplete="off"
            type="text"
            {...formik.getFieldProps("name")}
            placeholder="Digite Seu Nome:"
          />
          {formik.touched.name && formik.errors.name ? (
            <span>{formik.errors.name}</span>
          ) : null}
        </div>
        <div>
          <input
            autoComplete="off"
            type="text"
            {...formik.getFieldProps("email")}
            placeholder="Digite Seu E-mail:"
          />
          {formik.touched.email && formik.errors.email ? (
            <span>{formik.errors.email}</span>
          ) : null}
        </div>
        <div>
          <MaskedInput
            mask={[
              "(",
              /(?=[0-9])/,
              /(?=[0-9])/,
              ")",
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              "-",
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/
            ]}
            guide={false}
            autoComplete="off"
            type="text"
            {...formik.getFieldProps("phone")}
            placeholder="Digite Seu Telefone:"
          />
          {formik.touched.phone && formik.errors.phone ? (
            <span>{formik.errors.phone}</span>
          ) : null}
        </div>
        <div>
          <input
            autoComplete="off"
            type="password"
            {...formik.getFieldProps("password")}
            placeholder="Digite Sua Senha:"
          />
          {formik.touched.password && formik.errors.password ? (
            <span>{formik.errors.password}</span>
          ) : null}
        </div>
        <div>
          <input
            autoComplete="off"
            type="password"
            {...formik.getFieldProps("confirmPassword")}
            placeholder="Digite Sua Senha:"
          />
          {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
            <span>{formik.errors.confirmPassword}</span>
          ) : null}
        </div>
        <div>
          <input type="submit" value="Cadastrar" />
        </div>
      </form>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
