import React, { useState } from "react";
import ReactDom from "react-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import MaskedInput from "react-text-mask";

function App() {
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      passwordC: ""
    },
    validationSchema: yup.object({
      name: yup.string().required("Campo Obrigatório"),
      email: yup
        .string()
        .required("Campo Obrigatório")
        .email("Email Inválido, Tente Novamente!"),
      phone: yup
        .string()
        .required("Campo Obrigatório")
        .min(14, "Telefone Inválido, Tente Novamente!"),
      password: yup
        .string()
        .required("Campo Obrigatório")
        .matches(/[0-9]/, "A senha deve conter número")
        .matches(/[a-z]/, "A senha deve conter letra minúscula")
        .matches(/[A-Z]/, "A senha deve conter letra maiúscula")
        .min(8, "Deve conter pelo menos 8 caracteres"),
      passwordC: yup
        .string()
        .required("Campo Obrigatório")
        .oneOf([yup.ref("password"), null], "As senhas não correspondem")
    }),
    onSubmit(values) {
      if (formik.isValid) {
        const data = {
          name: values.name.toLocaleLowerCase(),
          email: values.email.toLocaleLowerCase(),
          phone: values.phone
            .replace("(", "")
            .replace(")", "")
            .replace("-", ""),
          password: values.password
        };
      }
    }
  });
  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <div>
          <input
            placeholder="Digite seu Nome"
            type="text"
            {...formik.getFieldProps("name")}
          />
          {formik.touched.name && formik.errors.name ? (
            <span>{formik.errors.name}</span>
          ) : null}
        </div>
        <div>
          <input
            placeholder="Digite seu E-mail"
            type="text"
            {...formik.getFieldProps("email")}
          />
          {formik.touched.email && formik.errors.email ? (
            <span>{formik.errors.email}</span>
          ) : null}
        </div>
        <div>
          <MaskedInput
            mask={[
              "(",
              /(?=[0-9])/,
              /(?=[0-9])/,
              ")",
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              "-",
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/,
              /(?=[0-9])/
            ]}
            guide={false}
            placeholder="Digite seu Telefone"
            type="text"
            {...formik.getFieldProps("phone")}
          />
          {formik.touched.phone && formik.errors.phone ? (
            <span>{formik.errors.phone}</span>
          ) : null}
        </div>
        <div>
          <input
            placeholder="Digite sua Senha"
            type="password"
            {...formik.getFieldProps("password")}
          />
          {formik.touched.password && formik.errors.password ? (
            <span>{formik.errors.password}</span>
          ) : null}
        </div>
        <div>
          <input
            placeholder="Repetir Senha"
            type="password"
            {...formik.getFieldProps("passwordC")}
          />
          {formik.touched.passwordC && formik.errors.passwordC ? (
            <span>{formik.errors.passwordC}</span>
          ) : null}
        </div>
        <div>
          <input type="submit" value="cadastrar" />
        </div>
      </form>
      <div></div>
    </>
  );
}
ReactDom.render(<App />, document.getElementById("root"));
