import React from "react";
import ReactDOM from "react-dom";
import Form from "./Form/Form";
import "./index.css";
function App() {
  return (
    <>
      <Form />
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
