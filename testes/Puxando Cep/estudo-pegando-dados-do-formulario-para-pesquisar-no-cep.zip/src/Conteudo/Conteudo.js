import React from "react";
import "./conteudo.css";
function Conteudo(props) {
  return (
    <section>
      <div className="container">
        <h1>Cep: </h1>
        <p>{props.cep}</p>
        <br />
        <h1>Rua:</h1>
        <p>{props.logradouro}</p>
        <br />
        <h1>Bairro: </h1>
        <p>{props.bairro}</p>
        <br />
        <h1>Cidade: </h1>
        <p>{props.localidade}</p>
        <br />
        <h1>Estado: </h1>
        <p> {props.uf}</p>
        <br />
      </div>
    </section>
  );
}
export default Conteudo;
