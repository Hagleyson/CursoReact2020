import React, { useCallback, useState } from "react";
import "./form.css";
import Conteudo from "../Conteudo/Conteudo";
function Form() {
  const [valor, setValor] = useState("");
  const [data, setData] = useState(null);
  const [visible, setVisible] = useState(false);
  const handleChange = useCallback(
    (e) => {
      setValor(e.target.value);
    },
    [setValor]
  );

  const handleSubmit = useCallback(
    (event) => {
      event.preventDefault();
      async function fetchData(val) {
        if (val === "") {
          alert("Digite um Cep!");
        } else {
          await fetch("https://viacep.com.br/ws/" + val + "/json/")
            .then((res) => {
              return res.json();
            })
            .then((resp) => {
              setVisible((prev) => {
                return !prev;
              });
              setData(resp);
            })
            .catch((err) => {
              setData(null);
            });
        }
      }
      fetchData(valor);
      setValor("");
    },
    [valor, setValor, setVisible]
  );

  return (
    <>
      <fieldset>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={valor}
            onChange={handleChange}
            placeholder="Digite o seu cep"
          />
          <input type="Submit" defaultValue="PESQUISAR" />
        </form>
      </fieldset>
      {visible && <Conteudo {...data} />}
    </>
  );
}

export default Form;
