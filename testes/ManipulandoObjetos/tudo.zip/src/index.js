import React, { useCallback, useState } from "react";
import ReactDOM from "react-dom";

function App() {
  const [vendas, setVendas] = useState({
    opcoesDePreco: {
      valorMaximo: 40,
      valorMinimo: 30
    },
    opcoesDeIdade: {
      lacamentoMaximo: 2015,
      lacamentoMinimo: 2000
    },
    nome: "Siena",
    fabricante: "Fiat"
  });
  const handleAtualizar = useCallback(() => {
    let v = { ...vendas };
    v.opcoesDePreco = { ...vendas.opcoesDePreco };
    v.opcoesDeIdade = { ...vendas.opcoesDeIdade };
    v.opcoesDeIdade = {
      lacamentoMaximo: 2020,
      lacamentoMinimo: 2018
    };
    v.opcoesDePreco = {
      valorMaximo: 90,
      valorMinimo: 60
    };
    v.nome = "Corola";
    v.fabricante = "toyota";
    setVendas(v);
  }, [setVendas, vendas]);
  const handleCriar = useCallback(() => {
    let v = { ...vendas };
    v.opcoesDePreco = { ...vendas.opcoesDePreco };
    v.opcoesDeIdade = { ...vendas.opcoesDeIdade };
    v.opcoesDePreco = { ...vendas.opcoesDePreco, novoPreco: 25 };
    setVendas(v);
  }, [setVendas, vendas]);
  const handleDelete = useCallback(() => {
    let v = { ...vendas };
    v.opcoesDePreco = { ...vendas.opcoesDePreco };
    v.opcoesDeIdade = { ...vendas.opcoesDeIdade };
    delete v.opcoesDeIdade;
    delete v.opcoesDePreco;
    setVendas(v);
    console.log(v);
  }, [setVendas, vendas]);
  return (
    <>
      <h1>Carro</h1>
      {vendas.nome ? <h2>Nome: {vendas.nome}</h2> : null}
      {vendas.fabricante ? <h2>Fabricante: {vendas.fabricante}</h2> : null}
      {vendas.opcoesDePreco ? (
        <h2>
          Valor de R${vendas.opcoesDePreco.valorMinimo},000 a R$
          {vendas.opcoesDePreco.valorMaximo},000
        </h2>
      ) : null}

      {vendas.opcoesDePreco && vendas.opcoesDePreco.novoPreco ? (
        <h2>Preço promocional {vendas.opcoesDePreco.novoPreco}</h2>
      ) : null}
      {vendas.opcoesDeIdade ? (
        <h2>
          ano de lançamento de {vendas.opcoesDeIdade.lacamentoMinimo} até
          {vendas.opcoesDeIdade.lacamentoMaximo}
        </h2>
      ) : null}

      <button onClick={handleAtualizar}>Mudar</button>
      <button onClick={handleCriar}>Criar</button>
      <button onClick={handleDelete}>Delete</button>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
