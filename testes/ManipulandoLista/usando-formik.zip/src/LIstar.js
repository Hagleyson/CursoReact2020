import React from "react";

function Listar({ v, a, ap }) {
  console.log(v);
  return (
    <>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Idade</th>
            <th>Sexo</th>
          </tr>
        </thead>
        <tbody>
          {v.map((cur) => {
            return (
              <tr key={cur.id}>
                <td>{cur.id}</td>
                <td>{cur.nome}</td>
                <td>{cur.idade}</td>
                <td>{cur.sexo}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button onClick={a}>Atualizar</button>
      <button onClick={ap}>Apagar</button>
    </>
  );
}
export default Listar;
/*
 */
