import React, { useCallback, useState } from "react";
import ReactDOM from "react-dom";
import { useFormik } from "formik";
import Listar from "./LIstar";
function App() {
  const [gid, setGid] = useState(0);

  function gerarID() {
    setGid(() => {
      return gid + 1;
    });
    return gid;
  }
  const [view, setView] = useState(false);
  const formik = useFormik({
    initialValues: { nome: "", idade: "", sexo: "" },
    onSubmit(values) {
      const data = {
        id: gerarID(),
        nome: values.nome,
        idade: values.idade,
        sexo: values.sexo
      };
      setPessoas(pessoas.concat(data));
    }
  });
  const [pessoas, setPessoas] = useState([]);
  const handleListar = useCallback(() => {
    setView((prev) => {
      console.log(view);
      return !prev;
    });
  }, [setView, view]);

  const handleAtualizar = useCallback(() => {
    setPessoas(
      pessoas.map((cur) => {
        if (cur.id === 3) {
          return {
            ...cur,
            nome: "new Name",
            idade: "new year",
            sexo: "new sexo"
          };
        } else {
          return cur;
        }
      })
    );
  }, [setPessoas, pessoas]);
  const handleApagar = useCallback(() => {
    setPessoas(
      pessoas.filter((cur) => {
        return cur.id !== 3;
      })
    );
  }, [setPessoas, pessoas]);
  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <input
          type="text"
          placeholder="Nome"
          {...formik.getFieldProps("nome")}
        />
        <input
          type="text"
          placeholder="Idade"
          {...formik.getFieldProps("idade")}
        />
        <input
          type="text"
          placeholder="Sexo"
          {...formik.getFieldProps("sexo")}
        />
        <input type="submit" value="cadastrar" />
      </form>
      <button onClick={handleListar}>Listar</button>
      {view && <Listar v={pessoas} a={handleAtualizar} ap={handleApagar} />}
    </>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  rootElement
);
