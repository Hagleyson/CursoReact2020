import React, { useCallback, useState } from "react";
import ReactDOM from "react-dom";
import { useFormik } from "formik";
import "./styles.css";

function App() {
  const [ide, setIde] = useState(11);
  function incrementarId() {
    setIde(() => {
      return ide + 1;
    });
    return ide;
  }
  const [games, setGames] = useState([
    { id: "0", title: "Guitar Hero", release: 2005 },
    { id: "1", title: "GTA: San Andreas", release: 2004 },
    { id: "2", title: "Resident Evil 4", release: 2005 },
    { id: "3", title: "Shadow of the Colossus", release: 2005 },
    { id: "4", title: "God of War II", release: 2007 },
    { id: "5", title: "Dragon Ball Z: Budokai 3", release: 2004 },
    { id: "6", title: "Onimusha 3: Demon Siege", release: 2004 },
    { id: "7", title: "Call of Duty 3", release: 2006 },
    { id: "8", title: "Gran Turismo 4", release: 2004 },
    { id: "9", title: "Black", release: 2006 },
    { id: "10", title: "Resident Evil 7", release: "2017" }
  ]);

  const formik = useFormik({
    initialValues: {
      title: "",
      release: ""
    },
    onSubmit(values) {
      const data = {
        id: incrementarId(),
        title: values.title,
        release: values.release
      };
      setGames(games.concat(data));
    }
  });
  const handleAtualizar = useCallback(() => {
    setGames(
      games.map((cur) => {
        if (cur.id === "4") {
          return { ...cur, title: "hagleyson", release: "1996" };
        } else {
          return cur;
        }
      })
    );
  }, [setGames, games]);
  const handleRemove = useCallback(() => {
    setGames(
      games.filter((cur) => {
        return cur.id !== "4";
      })
    );
  }, [setGames, games]);
  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <input
          placeholder="Nome"
          type="text"
          {...formik.getFieldProps("title")}
        />
        <input
          placeholder="Ano Lançamento"
          type="text"
          {...formik.getFieldProps("release")}
        />
        <input type="submit" value="cadastrar" />
      </form>
      <table>
        <thead>
          <tr>
            <th>Id</th>
            <th>Titulo</th>
            <th>Laçamento</th>
          </tr>
        </thead>
        <tbody>
          {games.map((cur, idx, arr) => {
            return (
              <tr key={cur.id}>
                <td>{cur.id}</td>
                <td>{cur.title}</td>
                <td>{cur.release}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button onClick={handleAtualizar}>Atualizar</button>
      <button onClick={handleRemove}>Apagar</button>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
