import React, { useCallback, useState } from "react";
import ReactDOM from "react-dom";

function App() {
  const [pessoa, setPessoa] = useState([]);
  const [gid, setGid] = useState(1);
  const [nome, setNome] = useState();
  const [idade, setIdade] = useState();
  const handleNome = useCallback(
    (e) => {
      setNome(e.target.value);
    },
    [setNome]
  );
  const handleSobrenome = useCallback(
    (e) => {
      setIdade(e.target.value);
    },
    [setIdade]
  );
  function gerarId() {
    setGid((prev) => {
      return prev + 1;
    });
    return gid;
  }
  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault();
      let p = {
        id: gerarId(),
        nome: nome,
        idade: idade
      };
      console.log({ ...p });
      setPessoa(pessoa.concat({ ...p }));
    },
    [pessoa, setPessoa, nome, idade]
  );
  const handleApagar = useCallback(() => {
    setPessoa(
      pessoa.filter((cur) => {
        return cur.id !== 1;
      })
    );
  }, [setPessoa, pessoa]);
  const handleEditar = useCallback(() => {
    setPessoa(
      pessoa.map((cur) => {
        if (cur.id === 5) {
          return { ...cur, nome: "Sandra", idade: "32" };
        } else {
          return cur;
        }
      })
    );
  }, [setPessoa, pessoa]);
  return (
    <>
      <form onSubmit={handleSubmit}>
        <input placeholder="nome" onChange={handleNome} />
        <input placeholder="Sobrenome" onChange={handleSobrenome} />
        <input type="submit" value="Cadastrar" />
      </form>
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>nome</th>
            <th>Idade</th>
          </tr>
        </thead>
        <tbody>
          {pessoa.map((cur) => {
            return (
              <tr key={cur.id}>
                <td>{cur.id}</td>
                <td>{cur.nome}</td>
                <td>{cur.idade}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button onClick={handleApagar}>Apagar</button>
      <button onClick={handleEditar}>Editar</button>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
