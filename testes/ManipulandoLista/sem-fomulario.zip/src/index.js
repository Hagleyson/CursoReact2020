import React, { useCallback, useState } from "react";
import ReactDOM from "react-dom";

function App() {
  const [pessoa, setPessoa] = useState([
    { id: "1", nome: "hagleyson", sobrenome: "Fernandes" },
    { id: "2", nome: "Sandra", sobrenome: "Fernandes" },
    { id: "3", nome: "José", sobrenome: "Fernandes" },
    { id: "4", nome: "Maria", sobrenome: "Fernandes" }
  ]);
  const handleApagar = useCallback(() => {
    setPessoa(
      pessoa.filter((cur) => {
        return cur.id !== "1";
      })
    );
  }, [pessoa, setPessoa]);
  const handleAtualizar = useCallback(() => {
    setPessoa(
      pessoa.map((cur) => {
        if (cur.id === "2") {
          return { ...cur, nome: "Sandrinha" };
        } else {
          return cur;
        }
      })
    );
  }, [pessoa, setPessoa]);
  return (
    <>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>NOME</th>
            <th>SOBRENOME</th>
          </tr>
        </thead>
        <tbody>
          {pessoa.map((cur) => {
            return (
              <tr key={cur.id}>
                <td>{cur.id}</td>
                <td>{cur.nome}</td>
                <td>{cur.sobrenome}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button onClick={handleApagar}>Apagar</button>
      <button onClick={handleAtualizar}>Atualizar</button>
    </>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
